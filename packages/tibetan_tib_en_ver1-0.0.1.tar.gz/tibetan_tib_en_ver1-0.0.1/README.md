tibetan-english hybrid model

| Feature | Description |
| --- | --- |
| **Name** | `tibetan_tib_en_ver1` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.5.3,<3.6.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `morphologizer`, `trainable_lemmatizer`, `parser` |
| **Components** | `tok2vec`, `tagger`, `morphologizer`, `trainable_lemmatizer`, `parser` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `MIT` |
| **Author** | [James Engels](n/a) |

### Label Scheme

<details>

<summary>View label scheme (230 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `ADJ`, `ADJ__NumType=Ord`, `ADP`, `ADP__Case=Abl`, `ADP__Case=Agn`, `ADP__Case=All`, `ADP__Case=Cmp`, `ADP__Case=Com`, `ADP__Case=Ela`, `ADP__Case=Gen`, `ADP__Case=Loc`, `ADP__Case=Qot`, `ADP__Case=Ter`, `ADV`, `ADV__AdvType=Dir`, `ADV__AdvType=Intens`, `ADV__AdvType=Mim`, `ADV__AdvType=Tim`, `ADV__PronType=Dem`, `AUX`, `AUX__Polarity=Neg`, `AUX__VerbForm=Vnoun`, `DET`, `DET__Mood=Imp`, `DET__Number=Plur`, `DET__PronType=Dem`, `DET__PronType=Emp`, `DET__PronType=Ind`, `DET__PronType=Tsam`, `DET__Tense=Past`, `INTJ`, `NOUN`, `NOUN__NounType=Rel`, `NOUN__Number=Coll`, `NOUN__Number=Sing`, `NOUN__Tense=Fut/Past`, `NOUN__Tense=Fut/Pres`, `NOUN__Tense=Fut/Pres\|VerbForm=Vnoun`, `NOUN__Tense=Fut\|VerbForm=Vnoun`, `NOUN__Tense=Past/Pres`, `NOUN__Tense=Past/Pres\|VerbForm=Vnoun`, `NOUN__Tense=Past\|VerbForm=Vnoun`, `NOUN__Tense=Pres`, `NOUN__Tense=Pres\|VerbForm=Vnoun`, `NOUN__VerbForm=Vnoun`, `NUM`, `NUM__NumType=Card\|NumForm=Digit`, `NUM__NumType=Card\|NumForm=Word`, `NUM__Tense=Fut/Past`, `NUM__Tense=Fut/Pres\|VerbForm=Vnoun`, `PART`, `PART__Mood=Imp`, `PART__Mood=Ind`, `PART__Polarity=Neg`, `PART__Polarity=Xor`, `PRON`, `PRON__PronType=Ind`, `PRON__PronType=Int`, `PRON__PronType=Prs`, `PRON__Reflex=Yes`, `PROPN`, `PROPN__Tense=Fut/Pres\|VerbForm=Vnoun`, `PUNCT`, `SCONJ`, `SCONJ__Case=Abl`, `SCONJ__Case=Agn`, `SCONJ__Case=All`, `SCONJ__Case=Are`, `SCONJ__Case=Com`, `SCONJ__Case=Cont`, `SCONJ__Case=Ela`, `SCONJ__Case=Gen`, `SCONJ__Case=Impf`, `SCONJ__Case=Loc`, `SCONJ__Case=Odd`, `SCONJ__Case=Rung`, `SCONJ__Case=Sem`, `SCONJ__Case=Ter`, `VERB`, `VERB__Mood=Imp`, `VERB__Mood=Imp\|VerbForm=Vnoun`, `VERB__Mood=Qot`, `VERB__Number=Sing`, `VERB__Number=Sing\|VerbForm=Vnoun`, `VERB__Polarity=Neg`, `VERB__Polarity=Neg\|VerbForm=Vnoun`, `VERB__PronType=Ind`, `VERB__PronType=Int`, `VERB__Tense=Fut`, `VERB__Tense=Fut/Past`, `VERB__Tense=Fut/Past\|VerbForm=Vnoun`, `VERB__Tense=Fut/Pres`, `VERB__Tense=Fut/Pres\|Mood=Ind`, `VERB__Tense=Fut/Pres\|VerbForm=Vnoun`, `VERB__Tense=Fut\|VerbForm=Vnoun`, `VERB__Tense=Past`, `VERB__Tense=Past/Pres`, `VERB__Tense=Past/Pres\|VerbForm=Vnoun`, `VERB__Tense=Past/Pres\|VerbForm=Vnoun\|Polarity=Neg`, `VERB__Tense=Past\|Mood=Ind`, `VERB__Tense=Past\|VerbForm=Vnoun`, `VERB__Tense=Pres`, `VERB__Tense=Pres\|VerbForm=Vnoun`, `VERB__VerbForm=Vnoun`, `VERB__VerbForm=Vnoun\|Tense=Pres`, `VERB__VerbForm=Vnoun\|VerbType=Aux`, `VERB__VerbType=Aux`, `X` |
| **`morphologizer`** | `POS=VERB\|VerbForm=Vnoun`, `Case=Ter\|POS=ADP`, `Case=Gen\|POS=ADP`, `POS=VERB\|Tense=Fut\|VerbForm=Vnoun`, `Number=Sing\|POS=NOUN`, `POS=ADJ`, `Mood=Qot\|POS=VERB`, `POS=PUNCT`, `POS=PROPN`, `Case=All\|POS=ADP`, `POS=VERB\|Tense=Fut/Pres`, `Mood=Ind\|POS=PART`, `POS=PRON\|PronType=Int`, `POS=DET\|PronType=Ind`, `Case=Abl\|POS=ADP`, `POS=VERB\|Tense=Past`, `Case=Agn\|POS=ADP`, `POS=VERB\|Tense=Fut/Pres\|VerbForm=Vnoun`, `NumForm=Word\|NumType=Card\|POS=NUM`, `NounType=Rel\|POS=NOUN`, `POS=VERB\|Tense=Pres`, `POS=VERB\|Tense=Fut/Past`, `Case=Impf\|POS=SCONJ`, `Number=Plur\|POS=DET`, `POS=VERB\|Tense=Pres\|VerbForm=Vnoun`, `POS=VERB\|Tense=Past/Pres\|VerbForm=Vnoun`, `POS=DET`, `POS=DET\|PronType=Dem`, `Case=Loc\|POS=ADP`, `Case=Com\|POS=ADP`, `POS=VERB\|Tense=Past\|VerbForm=Vnoun`, `POS=VERB`, `Case=Com\|POS=SCONJ`, `Case=Ela\|POS=ADP`, `Number=Coll\|POS=NOUN`, `Mood=Imp\|POS=VERB`, `Mood=Imp\|POS=PART`, `POS=PART`, `POS=VERB\|Tense=Fut`, `AdvType=Intens\|POS=ADV`, `Case=Ter\|POS=SCONJ`, `POS=VERB\|Tense=Fut/Past\|VerbForm=Vnoun`, `POS=PART\|Polarity=Neg`, `POS=DET\|PronType=Emp`, `Case=Sem\|POS=SCONJ`, `Case=Ela\|POS=SCONJ`, `POS=ADV\|PronType=Dem`, `POS=AUX`, `POS=VERB\|VerbType=Aux`, `POS=PRON\|PronType=Prs`, `POS=VERB\|Polarity=Neg\|VerbForm=Vnoun`, `POS=VERB\|Polarity=Neg`, `POS=PRON\|Reflex=Yes`, `Case=Loc\|POS=SCONJ`, `POS=PART\|Polarity=Xor`, `Case=Agn\|POS=SCONJ`, `POS=VERB\|Tense=Past/Pres`, `POS=AUX\|VerbForm=Vnoun`, `AdvType=Tim\|POS=ADV`, `NumType=Ord\|POS=ADJ`, `Case=All\|POS=SCONJ`, `Case=Gen\|POS=SCONJ`, `POS=DET\|PronType=Tsam`, `Case=Cmp\|POS=ADP`, `POS=X`, `POS=VERB\|VerbForm=Vnoun\|VerbType=Aux`, `POS=PRON\|PronType=Ind`, `AdvType=Mim\|POS=ADV`, `POS=AUX\|Polarity=Neg`, `Case=Abl\|POS=SCONJ`, `Case=Qot\|POS=ADP`, `POS=INTJ`, `AdvType=Dir\|POS=ADV`, `Case=Odd\|POS=SCONJ`, `Case=Rung\|POS=SCONJ`, `Case=Are\|POS=SCONJ`, `Case=Cont\|POS=SCONJ`, `POS=NOUN`, `NumForm=Digit\|NumType=Card\|POS=NUM`, `POS=VERB\|PronType=Ind`, `Mood=Imp\|POS=VERB\|VerbForm=Vnoun`, `Mood=Ind\|POS=VERB\|Tense=Fut/Pres`, `POS=VERB\|Polarity=Neg\|Tense=Past/Pres\|VerbForm=Vnoun`, `Mood=Ind\|POS=VERB\|Tense=Past`, `Number=Sing\|POS=VERB`, `POS=ADP`, `POS=SCONJ`, `POS=PRON`, `POS=ADV`, `POS=NUM`, `POS=NOUN\|Tense=Pres`, `POS=NOUN\|Tense=Fut/Past`, `POS=NOUN\|Tense=Pres\|VerbForm=Vnoun`, `POS=NOUN\|VerbForm=Vnoun`, `POS=NOUN\|Tense=Fut/Pres\|VerbForm=Vnoun`, `POS=NOUN\|Tense=Past/Pres\|VerbForm=Vnoun`, `POS=NOUN\|Tense=Past\|VerbForm=Vnoun`, `POS=NUM\|Tense=Fut/Past`, `POS=NOUN\|Tense=Fut/Pres`, `Number=Sing\|POS=VERB\|VerbForm=Vnoun`, `POS=PROPN\|Tense=Fut/Pres\|VerbForm=Vnoun`, `POS=DET\|Tense=Past`, `POS=VERB\|PronType=Int`, `Mood=Imp\|POS=DET`, `POS=NOUN\|Tense=Past/Pres`, `POS=NUM\|Tense=Fut/Pres\|VerbForm=Vnoun`, `POS=NOUN\|Tense=Fut\|VerbForm=Vnoun` |
| **`parser`** | `ROOT`, `arg1`, `arg2`, `arg2:hon`, `arg2:lvc`, `arg3`, `argcl`, `aux`, `aux:lvc`, `aux:redup`, `cop`, `dep`, `obl`, `obl:adv`, `obl:arg` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 0.02 |
| `POS_ACC` | 0.02 |
| `MORPH_ACC` | 0.02 |
| `LEMMA_ACC` | 0.02 |
| `DEP_UAS` | 0.01 |
| `DEP_LAS` | 0.01 |
| `SENTS_P` | 0.07 |
| `SENTS_R` | 0.01 |
| `SENTS_F` | 0.01 |
| `TOK2VEC_LOSS` | 540783.75 |
| `TAGGER_LOSS` | 929.42 |
| `MORPHOLOGIZER_LOSS` | 929.30 |
| `TRAINABLE_LEMMATIZER_LOSS` | 640.41 |
| `PARSER_LOSS` | 293173.44 |